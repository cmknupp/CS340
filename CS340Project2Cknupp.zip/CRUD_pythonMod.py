from pymongo import MongoClient
from bson.objectid import ObjectId

# URL Lib to make sure that our input is 'sane'
import urllib.parse

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    #initializer that accepts username and password as input
    def __init__(self, input_user, input_pass):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        if input_user != "":
            USER = input_user 
        else:
            raise Exception ("Invalid User")
        if input_pass != "":
            PASS = input_pass
        else:
            raise Exception ("Invalid Password")
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34894  #31580
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
       
        #commenting out original init  
    """def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34894  #31580
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]"""

# C.Knupp completed the create method to implement the C in CRUD.
    def createMethod(self, data = None)-> bool:
        """The create method: Accepts data as a dictionary, returns a bool"""
        if isinstance(data, dict): #validating that data is a dictionary
            self.database.animals.insert_one(data)  #insert data
            return True
        else:
            raise Exception("Invalid input parameter")
            return False
 
 # C.Knupp created a read method to implement the R in CRUD.
    def readMethod(self, data)-> list:
        """The read method: Accepts a dictionary search returns a list"""
        results = [] #empty list for results
        if isinstance(data, dict): #validating query is dictionary
            results = list(self.database.animals.find(data))
        else:
            raise Exception("Invalid search Parameters")
        return results
    
# C.Knupp created a read method to implement the R in CRUD.
    def readMethod(self, data)-> list:
        """The read method: Accepts a dictionary search returns a list"""
        results = [] #empty list for results
        if isinstance(data, dict): #validating query is dictionary
            results = list(self.database.animals.find(data))
        else:
            raise Exception("Invalid search Parameters")
        return results

# C.Knupp created an update one method to implement the U in CRUD.
    def updateOneMethod(self, matchData, updateInfo)-> int:
        """The updateOne method: Accepts a dictionary search and dictionary update values, 
           returns an integer of number modified"""
        if isinstance(matchData, dict): #validate search criteria is a dictionary
            if isinstance(updateInfo, dict): #validating update information is a dictionarys
                results = self.database.animals.update_one(matchData, {"$set": updateInfo})
                return results.modified_count
            else:
                raise Exception("Invalid Update Parameters")
        else:
            raise Exception("Invalid Search Parameters")
            

# C.Knupp created an updateMany method to implement the U in CRUD.
    def updateManyMethod(self, matchData, updateInfo)-> int:
        """The updateMany method: Accepts a dictionary search and dictionary update values, 
           returns an integer of number modified"""
        if isinstance(matchData, dict): #validate search criteria is a dictionary
            if isinstance(updateInfo, dict): #validating update information is a dictionarys
                results = self.database.animals.update_many(matchData, {"$set": updateInfo})
                return results.modified_count
            else:
                raise Exception("Invalid Update Parameters")
        else:
            raise Exception("Invalid Search Parameters")
            
# C.Knupp created a deleteMethod to implement the D in CRUD
    def deleteOneMethod(self, data)-> int:
        """The deleteOne method accepts a dictionary of critera for match and
           returns an integer for number of entries deleted.  Should return 1."""
        if isinstance(data, dict): #validating input is a dictionary
            results = self.database.animals.delete_one(data)
            return results.deleted_count
        else:
            raise Exception("Invalid Search Parameters")
            
# C.Knupp created a deleteMethod to implement the D in CRUD
    def deleteManyMethod(self, data)-> int:
        """The deleteMany method accepts a dictionary of critera for match and
           returns an integer for number of entries deleted."""
        if isinstance(data, dict): #validating input is a dictionary
            results = self.database.animals.delete_many(data)
            return results.deleted_count
        else:
            raise Exception("Invalid Search Parameters")
            
        
